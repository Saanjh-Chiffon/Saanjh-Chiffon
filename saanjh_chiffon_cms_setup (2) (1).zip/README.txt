# Saanjh Chiffon CMS files

This package contains:
- `index.html` — your supplied storefront updated to read the catalog from `products.json`
- `products.json` — initial product catalog
- `admin/index.html` and `admin/config.yml` — Decap CMS editor setup

## Important setup notes
1. These files are not yet published to GitHub or Netlify.
2. The repository must use the `main` branch, or update `branch` in `admin/config.yml`.
3. Decap CMS GitHub login needs a supported OAuth authentication flow. A GitHub account connection inside ChatGPT does not automatically configure the website's CMS login.
4. Do not put GitHub passwords or personal access tokens in these files.
5. After deploying, visit `/admin/`. Configure and test authentication before relying on it.
